import java.util.Random;


public class random {

  public static void main(String... aArgs){


    //note a single Random object is reused here
    Random randomGenerator = new Random();
    int randomInt = randomGenerator.nextInt(100);
    System.out.println("Generated : " + randomInt);
    }


  }
