class Cat{
  int age;
  public Cat(int catsAge){
    catsAge = age;
  }
  public void scare(){
    System.out.println("_Jump_");
  }
}
