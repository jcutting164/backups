public class BoolTest{
  public static void main(String[] args){
    Boolean tempBool = false;
    String str = "LVL";
    if(str != "LVL"){
      tempBool = true;
    }
    System.out.println(tempBool); //should be false
  }
}
