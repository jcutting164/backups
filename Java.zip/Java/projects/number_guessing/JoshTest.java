import java.util.*;

public class JoshTest {
  public static void main(String[] args){

  RandomNumberGenerator josh = new RandomNumberGenerator();


  // Ask user for input
  // Use the check method to see if they got it right
  boolean bool = false;
  int theNumber = josh.getRandomNumber();
  Scanner reader = new Scanner(System.in);

  while(bool == false){
    System.out.print("Enter a number: ");
    int userInput = reader.nextInt();
    bool = josh.checkMyNumber(userInput);

  }
  }
}
