import java.util.Random;

public class RandomNumberGenerator {

  int randomNumber;
  int userInput;
  public RandomNumberGenerator() {
    Random r = new Random();
    randomNumber = r.nextInt(100);
  }

  public int getUserInput(){
    return userInput;
  }

  public int getRandomNumber() {
    return randomNumber;
  }

  public boolean checkMyNumber(int userInput) {

    if (userInput == randomNumber){
      System.out.println("You have guessed correctly");
      return true;


    }else if(userInput > randomNumber){
      System.out.println("You are too high");
      return false;


    }else if(userInput < randomNumber){
      System.out.println("You are too low");
      return false;
    }else{
      return false;
    }
  }

  public static void main(String[] args){
    RandomNumberGenerator joshRand = new RandomNumberGenerator();

    int theNumber = joshRand.getRandomNumber();
    System.out.println(" The number is: " + theNumber);


  }

/*

  public static void main(String[] args){
    Random randomGenerator = new Random();
    int randomInt = randomGenerator.nextInt(100);
    boolean stop = true;
    main player = new main();
    while(stop == true){
      player.input();
      player.check(randomInt, userInput, stop);

    }
  }

*/

/*
  public void check(int randomInt, int userInput){
    if (userInput == randomInt){
      System.out.println("You have guessed correctly, you WIN!");
    }else if(userInput > randomInt){
      System.out.println("You are too high");
    }else if(userInput < randomInt){
      System.out.println("You are too low");
    }else if(userInput == randomInt){
      System.out.println("Error");
    }
  }

  public void input(){
    Scanner reader = new Scanner(System.in);
    System.out.println("Enter a number: ");
    int userInput = reader.nextInt();
  }
  */

}
