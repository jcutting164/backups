import java.time.*;
public class Time{

  private Clock clock = Clock.systemUTC();

  public void method1() {
      Instant now = Instant.now(clock);
      System.out.println(now);
      // Do something with 'now'
  }
  public static void main(String[] args){
    Time t = new Time();
    t.method1();
  }
}
