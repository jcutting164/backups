import java.util.*;
public class Constant{
  public void Wait(int time){
    try {
        Thread.sleep(time);                 //1000 milliseconds is one second.
    } catch(InterruptedException ex) {
        Thread.currentThread().interrupt();
    }
  }

  public void printj(String str){
    System.out.println("");
    Constant define = new Constant();
    String tempStr = str;
    ArrayList<String> myList = new ArrayList<String>(Arrays.asList(tempStr.split("")));
    for(int counter = 0; myList.size()>counter; counter++){
      System.out.print(myList.get(counter));
      define.Wait(50);
    }
  }
}
