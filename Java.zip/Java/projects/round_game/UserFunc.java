import java.util.*;
public class UserFunc{
  public UserFunc(){
  }

  public void getStats(ArrayList<String> statStr, HashMap<String, Integer> statMap){
    for(int i = 0; i < statStr.size(); i++){
      System.out.println(statStr.get(i)+ " value: " + statMap.get(statStr.get(i)));
    }
  }
  public void levelUp(ArrayList<String> statStr, HashMap<String, Integer> statMap){
    statMap.put("Lvl", statMap.get("Lvl") + 1);
    System.out.println("You have leveled up to level: "+ statMap.get("Lvl"));
    Scanner scan = new Scanner(System.in);
    int tempInt = 5;
    Boolean tempBool = false;
    String tempStr = "";
    for(int i = 0; i < 5; i++){
      tempBool = false;
      loop:
      while(tempBool == false){
        tempBool = false;
        System.out.println("Would you like to advance your Health, Strength, or Speed? You have "+tempInt+ " choices left" );
        tempStr = scan.nextLine();
        if(statStr.contains(tempStr) == true && ((! tempStr.equals("Lvl")) && (! tempStr.equals("XP")))){
          tempBool = true;
        }
        if(tempBool == false){
          continue loop;
        }
        statMap.put(tempStr, statMap.get(tempStr) + 1);
        System.out.println(tempStr+ " has been updated to: "+ statMap.get(tempStr));
        tempInt = tempInt - 1;
      }
    }
    statMap.put("XP", statMap.get("XP") - statMap.get("XP"));
  }
  public void checkLevelUp(HashMap<String, Integer> statMap, ArrayList<String> statStr, UserFunc user){
    if(statMap.get("XP") >= 500){
      user.levelUp(statStr, statMap);
    }
  }
  public int totalLuck(HashMap<String, Integer> statMap, HashMap<String, Integer> WeaponadjMap, ArrayList<Integer> WeaponStats){
    Integer tempInt = statMap.get("Luck"); // current speed stat
    tempInt = tempInt + WeaponStats.get(0);  // added to current weapon boost
    return tempInt;
  }
  public int totalStrength(HashMap<String, Integer> statMap, HashMap<String, Integer> WeaponadjMap, ArrayList<Integer> WeaponStats){
    Integer tempInt = statMap.get("Strength"); // current speed stat
    tempInt = tempInt + WeaponStats.get(1);  // added to current weapon boost
    return tempInt;
  }
  public int totalSpeed(HashMap<String, Integer> statMap, HashMap<String, Integer> WeaponadjMap, ArrayList<Integer> WeaponStats){
    Integer tempInt = statMap.get("Speed"); // current speed stat
    tempInt = tempInt + WeaponStats.get(2);  // added to current weapon boost
    return tempInt;
  }

  //public Boolean Fight(){
  //}
}
