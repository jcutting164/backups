import java.util.*;
public class Round{
  public static void main(String[] args){
    Setup ListDefine = new Setup(); // list creation start
    UserFunc user = new UserFunc();
    Scanner scan = new Scanner(System.in);
    ArrayList<String> ListA = new ArrayList<String>();
    ArrayList<String> ListB = new ArrayList<String>();
    ArrayList<String> ListC = new ArrayList<String>();
    ArrayList<String> WeaponListA = new ArrayList<String>();
    ArrayList<String> WeaponListB = new ArrayList<String>();
    ArrayList<String> WeaponListC = new ArrayList<String>();
    ArrayList<String> allLists = new ArrayList<String>();
    ArrayList<String> WeaponallLists = new ArrayList<String>();
    ArrayList<ArrayList<String>> fullList = new ArrayList<ArrayList<String>>();
    ArrayList<ArrayList<String>> WeaponfullList = new ArrayList<ArrayList<String>>();
    ListA = ListDefine.getListA(ListA);
    ListB = ListDefine.getListB(ListB);
    ListC = ListDefine.getListC(ListC);
    WeaponListA = ListDefine.getWeaponListA(WeaponListA);
    WeaponListB = ListDefine.getWeaponListB(WeaponListB);
    WeaponListC = ListDefine.getWeaponListC(WeaponListC);
    allLists = ListDefine.getAllLists(allLists, ListA, ListC, ListB);
    WeaponallLists = ListDefine.getWeaponAllLists(WeaponallLists, WeaponListA, WeaponListB, WeaponListC);
    fullList = ListDefine.getFullList(allLists, ListA, ListC, ListB, fullList);
    WeaponfullList = ListDefine.getWeaponFullList(WeaponallLists, WeaponListA, WeaponListB, WeaponListC, WeaponfullList);
    ArrayList<String> statStr = ListDefine.newStatList();
    HashMap<String, Integer> adjMap = ListDefine.getAdjMap();
    HashMap<String, Integer> WeaponadjMap = ListDefine.getWeaponAdjMap();
    HashMap<String, Integer> statMap = ListDefine.newStatMap(); // list creation end
    Weapons weapObj = new Weapons();
    ArrayList<ArrayList<String>> Inv = new ArrayList<ArrayList<String>>();
    ArrayList<String> Weaponadj_list = weapObj.getWeaponInfo(WeaponListA, WeaponListB, WeaponListC, WeaponallLists, WeaponfullList);
    ArrayList<Integer> WeapStat = weapObj.getWeaponStats(Weaponadj_list, WeaponadjMap);
    String WeaponName = weapObj.getWeaponName(Weaponadj_list);
    System.out.println(WeaponName);
  }
}


// possibly make with loop so you can cycle back through menus
// if attack, weapon inv will present, picks one, that becomes the weapon for the stat funcs
