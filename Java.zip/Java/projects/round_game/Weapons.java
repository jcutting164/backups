import java.util.*;

public class Weapons{

  Random randomGenerator = new Random();

  public Weapons(){
  }

  public ArrayList<String> getWeaponInfo(ArrayList<String> WeaponListA, ArrayList<String> WeaponListB, ArrayList<String> WeaponListC, ArrayList<String> WeaponallLists, ArrayList<ArrayList<String>> WeaponfullList){
    Random randomGenerator = new Random();
    ArrayList<String> Weaponadj_list = new ArrayList<String>();
    for(int i = 0; i < WeaponfullList.size(); i++){ //runs the amount of adjs
      int tempInt = randomGenerator.nextInt(WeaponfullList.get(i).size()); //make sure works
      Weaponadj_list.add(WeaponfullList.get(i).get(tempInt));
    }
    return Weaponadj_list;
  }
  public ArrayList<Integer> getWeaponStats(ArrayList<String> Weaponadj_list, HashMap<String, Integer> WeaponadjMap){
    ArrayList<Integer> WeaponStats = new ArrayList<Integer>();
    for(int i = 0; i < Weaponadj_list.size(); i++){
      WeaponStats.add(WeaponadjMap.get(Weaponadj_list.get(i)));
    }
    return WeaponStats;
  }
  public String getWeaponName(ArrayList<String> Weaponadj_list){
    String WeaponName = "";
    for(int i = 0; Weaponadj_list.size() > i; i ++){
      String tempStr = Weaponadj_list.get(i);
      WeaponName = WeaponName + " " + tempStr;
    }
    return WeaponName;
  }
}
