import java.util.*;
public class Setup{
  public Setup(){
  }

  public ArrayList<String> getListA(ArrayList<String> ListA){
    ListA.add("Huge");
    ListA.add("Tiny");
    ListA.add("Average");
    return ListA;
  }

  public ArrayList<String> getListB(ArrayList<String> ListB){
    ListB.add("Smart");
    ListB.add("Dumb");
    ListB.add("Normal");
    return ListB;
  }

  public ArrayList<String> getListC(ArrayList<String> ListC){
    ListC.add("Zombie");
    ListC.add("Skeletron");
    ListC.add("Giant");
    return ListC;
  }
  public ArrayList<String> getWeaponListA(ArrayList<String> WeaponListA){
    WeaponListA.add("Large"); // affects luck
    WeaponListA.add("Small");
    WeaponListA.add("Regular");
    return WeaponListA;
  }

  public ArrayList<String> getWeaponListB(ArrayList<String> WeaponListB){
    WeaponListB.add("Knife"); // affects Speed
    WeaponListB.add("Sword");
    WeaponListB.add("Long-Sword");
    return WeaponListB;
  }

  public ArrayList<String> getWeaponListC(ArrayList<String> WeaponListC){
    WeaponListC.add("Sharp"); // affects Strength
    WeaponListC.add("Dull");
    WeaponListC.add("Good");
    return WeaponListC;
  }
  public ArrayList<String> getAllLists(ArrayList<String> allLists, ArrayList<String> ListA, ArrayList<String> ListC, ArrayList<String> ListB){
    ArrayList<ArrayList<String>> tempList = new ArrayList<ArrayList<String>>();
    tempList.add(ListA);
    tempList.add(ListB);
    tempList.add(ListC);
    for(int counter = 0; counter < tempList.size(); counter++){
      for(int i = 0; i < tempList.get(counter).size(); i++){
        allLists.add(tempList.get(counter).get(i));
      }
    }
    return allLists;
  }
  public ArrayList<ArrayList<String>> getFullList(ArrayList<String> allLists, ArrayList<String> ListA, ArrayList<String> ListC, ArrayList<String> ListB, ArrayList<ArrayList<String>> fullList){
    fullList.add(ListA);
    fullList.add(ListB);
    fullList.add(ListC); // MAIN PART OF CODE THAT NEEDS UPDATING IF MORE LISTS ADDED.
    return fullList;
  }
  public HashMap<String, Integer> getAdjMap(){
    HashMap<String, Integer> adjMap = new HashMap<String, Integer>();
    adjMap.put("Huge", 20);
    adjMap.put("Tiny", 5);
    adjMap.put("Average", 10);
    adjMap.put("Smart", 20);
    adjMap.put("Dumb", 5);
    adjMap.put("Normal", 10);
    adjMap.put("Zombie", 10);
    adjMap.put("Skeletron", 5);
    adjMap.put("Giant", 20);
    return adjMap;
  }
  public ArrayList<String> getWeaponAllLists(ArrayList<String> WeaponallLists, ArrayList<String> WeaponListA, ArrayList<String> WeaponListC, ArrayList<String> WeaponListB){
    ArrayList<ArrayList<String>> tempList = new ArrayList<ArrayList<String>>();
    tempList.add(WeaponListA);
    tempList.add(WeaponListB);
    tempList.add(WeaponListC);
    for(int counter = 0; counter < tempList.size(); counter++){
      for(int i = 0; i < tempList.get(counter).size(); i++){
        WeaponallLists.add(tempList.get(counter).get(i));
      }
    }
    return WeaponallLists;
  }
  public ArrayList<ArrayList<String>> getWeaponFullList(ArrayList<String> WeaponallLists, ArrayList<String> WeaponListA, ArrayList<String> WeaponListC, ArrayList<String> WeaponListB, ArrayList<ArrayList<String>> WeaponfullList){
    WeaponfullList.add(WeaponListA);
    WeaponfullList.add(WeaponListB);
    WeaponfullList.add(WeaponListC); // MAIN PART OF CODE THAT NEEDS UPDATING IF MORE LISTS ADDED.
    return WeaponfullList;
  }
  public HashMap<String, Integer> getWeaponAdjMap(){
    HashMap<String, Integer> WeaponadjMap = new HashMap<String, Integer>();
    WeaponadjMap.put("Large", 20);
    WeaponadjMap.put("Small", 5);
    WeaponadjMap.put("Regular", 10);
    WeaponadjMap.put("Sharp", 20);
    WeaponadjMap.put("Dull", 5);
    WeaponadjMap.put("Good", 10);
    WeaponadjMap.put("Knife", 10);
    WeaponadjMap.put("Sword", 5);
    WeaponadjMap.put("Long-Sword", 20);
    return WeaponadjMap;
  }

  public ArrayList<String> newStatList(){
    ArrayList<String> statStr = new ArrayList<String>();
    statStr.add("Health"); // 0
    statStr.add("Strength"); // 1
    statStr.add("Speed"); // 2
    statStr.add("Lvl"); // 3
    statStr.add("XP"); // 4
    statStr.add("Luck"); // 5
    return statStr;
  }
  public HashMap<String, Integer> newStatMap(){
    HashMap<String, Integer> statMap = new HashMap<String, Integer>();
    statMap.put("Health", 20);
    statMap.put("Strength", 20);
    statMap.put("Speed", 20);
    statMap.put("Lvl", 1);
    statMap.put("XP", 0);
    statMap.put("Luck", 0);
    return statMap;
  }


}
