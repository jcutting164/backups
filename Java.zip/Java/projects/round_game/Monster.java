import java.util.*;

public class Monster{

  Random randomGenerator = new Random();

  public Monster(){
  }

  public ArrayList<String> getMonInfo(ArrayList<String> ListA, ArrayList<String> ListB, ArrayList<String> ListC, ArrayList<String> allLists, ArrayList<ArrayList<String>> fullList){
    Random randomGenerator = new Random();
    ArrayList<String> adj_list = new ArrayList<String>();

    for(int i = 0; i < fullList.size(); i++){ //runs the amount of adjs

      int tempInt = randomGenerator.nextInt(fullList.get(i).size()); //make sure works

      adj_list.add(fullList.get(i).get(tempInt));

    }
    return adj_list;
  }
  public ArrayList<Integer> getMonStats(ArrayList<String> adj_list, HashMap<String, Integer> adjMap){
    ArrayList<Integer> monStats = new ArrayList<Integer>();
    for(int i = 0; i < adj_list.size(); i++){
      monStats.add(adjMap.get(adj_list.get(i)));
    }
    return monStats;
  }
}
