import java.util.*;
public class Standard{
  public Standard(){
  }

  public void Wait(int time){
    try {
        Thread.sleep(time);
    } catch(InterruptedException ex) {
        Thread.currentThread().interrupt();
    }
  }

  public void printj(String str){
    System.out.println("");
    Standard define = new Standard();
    String tempStr = str;
    ArrayList<String> myList = new ArrayList<String>(Arrays.asList(tempStr.split("")));
    for(int counter = 0; myList.size()>counter; counter++){
      System.out.print(myList.get(counter));
      define.Wait(50);
    }
  }
}
