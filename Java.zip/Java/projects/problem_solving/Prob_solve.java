public class Prob_solve{
  
}
