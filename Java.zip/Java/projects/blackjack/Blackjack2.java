import java.util.*;
public class Blackjack2{
  public static void main(String[] args){
    Add define = new Add();
    UserFunc player1 = new UserFunc();
    define.printj(">>> Welcome to blackjack! ");
    define.Wait(1200);

    Scanner reader = new Scanner(System.in);
    define.printj("How many computer players would you like to play against? ");
    int comNum = reader.nextInt();



    ArrayList<String> myList = new ArrayList<String>();
    HashMap<String, Integer> myMap = new HashMap<String, Integer>();
    ArrayList<UserFunc> coms = new ArrayList<UserFunc>();
    ArrayList<Integer> values = new ArrayList<Integer>();
    ArrayList<ArrayList<String>> hands = new ArrayList<ArrayList<String>>();
    ArrayList<Boolean> busts = new ArrayList<Boolean>();
    ArrayList<Integer> nonbusts = new ArrayList<Integer>();
    ArrayList<Integer> goodvalues = new ArrayList<Integer>();
    ArrayList<Integer> comwin = new ArrayList<Integer>();
    myList = define.getList(myList);
    myMap = define.getMap(myMap);

    int myHandValue = 0;
    int comHandValue = 0;
    boolean myBust = true;  //sets variables used later
    boolean comBust = true;

    for(int counter = 0; comNum>counter; counter++){
      UserFunc playercom = new UserFunc();
      coms.add(playercom);
    }



    ArrayList<String> myHand = player1.getHand(myList);

    for(int counter = 0; comNum>counter; counter++){
        ArrayList<String> comHand = coms.get(counter).getHand(myList);
        hands.add(comHand);
    }




    myHandValue = player1.getValue(myHand, myMap);

    for(int counter = 0; comNum>counter; counter++){
      comHandValue = coms.get(counter).getValue(hands.get(counter), myMap);
      values.add(comHandValue);
    }

    for(int counter = 0; comNum>counter; counter++){
      comBust = coms.get(counter).checkBust(hands.get(counter), coms.get(counter), myList, myMap, values.get(counter));
      busts.add(comBust);
    }




    define.printj("Player 1 has a hand of" + myHand + " with a hand value of: " + myHandValue);
    define.Wait(1200);
    define.printj("Com 1 is showing " + hands.get(0).get(0));
    define.Wait(1200);






    myHand = player1.addCard(myHand, player1, myList, myMap, myBust, myHandValue, define);

    for(int counter = 0; comNum>counter; counter++){
      ArrayList<String> tempHand = new ArrayList<String>();
      tempHand = hands.get(counter);
      tempHand = coms.get(counter).computerChoice(hands.get(counter), coms.get(counter), myList, myMap, values.get(counter), busts.get(counter), define, counter);
      hands.add(counter, tempHand);
      hands.remove(counter + 1);
    }



    myBust = player1.checkBust(myHand, player1, myList, myMap, myHandValue);
    myHandValue = player1.getValue(myHand, myMap);

    values.clear();
    busts.clear();

    for(int counter = 0; comNum>counter; counter++){
      comHandValue = coms.get(counter).getValue(hands.get(counter), myMap);
      values.add(comHandValue);
    }



    for(int counter = 0; comNum>counter; counter++){
      comBust = coms.get(counter).checkBust(hands.get(counter), coms.get(counter), myList, myMap, values.get(counter));
      busts.add(comBust);
    }

    for(int counter = 0; comNum>counter; counter++){
      boolean tempBool = busts.get(counter);
      if (tempBool == true){
        nonbusts.add(counter);
      }
    }

    int tempNum = values.get(0);
    for(int counter = 0; values.size()>counter; counter++){
      if((tempNum == values.get(counter) && comwin.size() == 0) && (tempNum < 22 && values.get(counter) < 22)){
        comwin.add(counter);

      }else if(tempNum > values.get(counter) && values.get(counter) > 22){
        tempNum = values.get(counter);
        comwin.clear();
        comwin.add(counter);

      }else if(tempNum == values.get(counter) && values.get(counter) < 22){
        comwin.add(counter);

      }else if(tempNum < values.get(counter) && values.get(counter) < 22){
        tempNum = values.get(counter);
        comwin.clear();
        comwin.add(counter);

      }
    }

    myBust = player1.checkBust(myHand, player1, myList, myMap, myHandValue);

    if(myBust == true){
      if(tempNum < 22){
        define.printj("Coms"+comwin+" has won with a hand value of: "+ tempNum);


      }else{
        define.printj("Player1 has won with a hand of: "+ myHand+" with a hand value of: "+myHandValue);
      }


    }else if(myBust == true){
      if(myHandValue > tempNum){
        define.printj("Player1 has won with a hand of: "+ myHand+" with a hand value of: "+myHandValue);
      }
    }



  }
}
