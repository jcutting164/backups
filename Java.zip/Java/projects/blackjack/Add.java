import java.util.*;

public class Add{

  public Add(){
  }

  public HashMap<String, Integer> getMap(HashMap<String, Integer> theMap){
    theMap.put("Ace_of_Spades", 1);
    theMap.put("Two_of_Spades", 2);
    theMap.put("Three_of_Spades",3);
    theMap.put("Four_of_Spades",4);
    theMap.put("Five_of_Spades",5);
    theMap.put("Six_of_Spades",6);
    theMap.put("Seven_of_Spades",7);
    theMap.put("Eight_of_Spades",8);
    theMap.put("Nine_of_Spades",9);
    theMap.put("Ten_of_Spades",10);
    theMap.put("Jack_of_Spades",10);
    theMap.put("Queen_of_Spades",10);
    theMap.put("King_of_Spades",10);
    theMap.put("Ace_of_Diamonds",1);
    theMap.put("Two_of_Diamonds",2);
    theMap.put("Three_of_Diamonds",3);
    theMap.put("Four_of_Diamonds",4);
    theMap.put("Five_of_Diamonds",5);
    theMap.put("Six_of_Diamonds",6);
    theMap.put("Seven_of_Diamonds",7);
    theMap.put("Eight_of_Diamonds",8);
    theMap.put("Nine_of_Diamonds",9);
    theMap.put("Ten_of_Diamonds",10);
    theMap.put("Jack_of_Diamonds",10);
    theMap.put("Queen_of_Diamonds",10);
    theMap.put("King_of_Diamonds",10);
    theMap.put("Ace_of_Clubs",1);
    theMap.put("Two_of_Clubs",2);
    theMap.put("Three_of_Clubs",3);
    theMap.put("Four_of_Clubs",4);
    theMap.put("Five_of_Clubs",5);
    theMap.put("Six_of_Clubs",6);
    theMap.put("Seven_of_Clubs",7);
    theMap.put("Eight_of_Clubs",8);
    theMap.put("Nine_of_Clubs",9);
    theMap.put("Ten_of_Clubs",10);
    theMap.put("Jack_of_Clubs",10);
    theMap.put("Queen_of_Clubs",10);
    theMap.put("King_of_Clubs",10);
    theMap.put("Ace_of_Hearts",1);
    theMap.put("Two_of_Hearts",2);
    theMap.put("Three_of_Hearts",3);
    theMap.put("Four_of_Hearts",4);
    theMap.put("Five_of_Hearts",5);
    theMap.put("Six_of_Hearts",6);
    theMap.put("Seven_of_Hearts",7);
    theMap.put("Eight_of_Hearts",8);
    theMap.put("Nine_of_Hearts",9);
    theMap.put("Ten_of_Hearts",10);
    theMap.put("Jack_of_Hearts",10);
    theMap.put("Queen_of_Hearts",10);
    theMap.put("King_of_Hearts",10);
    return theMap;
  }

  public ArrayList<String> getList(ArrayList<String> theList){
    theList.add("Ace_of_Spades");
    theList.add("Two_of_Spades");
    theList.add("Three_of_Spades");
    theList.add("Four_of_Spades");
    theList.add("Five_of_Spades");
    theList.add("Six_of_Spades");
    theList.add("Seven_of_Spades");
    theList.add("Eight_of_Spades");
    theList.add("Nine_of_Spades");
    theList.add("Ten_of_Spades");
    theList.add("Jack_of_Spades");
    theList.add("Queen_of_Spades");
    theList.add("King_of_Spades");
    theList.add("Ace_of_Diamonds");
    theList.add("Two_of_Diamonds");
    theList.add("Three_of_Diamonds");
    theList.add("Four_of_Diamonds");
    theList.add("Five_of_Diamonds");
    theList.add("Six_of_Diamonds");
    theList.add("Seven_of_Diamonds");
    theList.add("Eight_of_Diamonds");
    theList.add("Nine_of_Diamonds");
    theList.add("Ten_of_Diamonds");
    theList.add("Jack_of_Diamonds");
    theList.add("Queen_of_Diamonds");
    theList.add("King_of_Diamonds");
    theList.add("Ace_of_Clubs");
    theList.add("Two_of_Clubs");
    theList.add("Three_of_Clubs");
    theList.add("Four_of_Clubs");
    theList.add("Five_of_Clubs");
    theList.add("Six_of_Clubs");
    theList.add("Seven_of_Clubs");
    theList.add("Eight_of_Clubs");
    theList.add("Nine_of_Clubs");
    theList.add("Ten_of_Clubs");
    theList.add("Jack_of_Clubs");
    theList.add("Queen_of_Clubs");
    theList.add("King_of_Clubs");
    theList.add("Ace_of_Hearts");
    theList.add("Two_of_Hearts");
    theList.add("Three_of_Hearts");
    theList.add("Four_of_Hearts");
    theList.add("Five_of_Hearts");
    theList.add("Six_of_Hearts");
    theList.add("Seven_of_Hearts");
    theList.add("Eight_of_Hearts");
    theList.add("Nine_of_Hearts");
    theList.add("Ten_of_Hearts");
    theList.add("Jack_of_Hearts");
    theList.add("Queen_of_Hearts");
    theList.add("King_of_Hearts");
    return theList;

  }

  public void Wait(int time){
    try {
        Thread.sleep(time);                 //1000 milliseconds is one second.
    } catch(InterruptedException ex) {
        Thread.currentThread().interrupt();
    }
  }

  public void printj(String str){
    System.out.println("");
		Add define = new Add();
		String tempStr = str;
		ArrayList<String> myList = new ArrayList<String>(Arrays.asList(tempStr.split("")));
		for(int counter = 0; myList.size()>counter; counter++){
			System.out.print(myList.get(counter));
			define.Wait(50);
		}
	}



}
