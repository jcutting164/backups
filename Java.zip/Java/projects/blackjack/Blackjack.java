import java.util.*;
public class Blackjack{
  public static void main(String[] args){

    define.printj(">>> Welcome to blackjack! ");




    Add define = new Add();

    define.Wait();
    ArrayList<String> myList = new ArrayList<String>();
    HashMap<String, Integer> myMap = new HashMap<String, Integer>();



    myList = define.getList(myList);      // creates deck with strings
    myMap = define.getMap(myMap);  //assigns strings values





    int myHandValue = 0;
    int comHandValue = 0;



    boolean myBust = true;  //sets variables used later
    boolean comBust = true;




    UserFunc player1 = new UserFunc();
    UserFunc playercom = new UserFunc();


    ArrayList<String> myHand = player1.getHand(myList);
    ArrayList<String> comHand = playercom.getHand(myList);



    myHandValue = player1.getValue(myHand, myMap);
    comHandValue = playercom.getValue(myHand, myMap);


    define.printj("Player 1 has a hand of" + myHand + " with a hand value of: " + myHandValue);

    define.Wait();

    define.printj("Com is showing " + comHand.get(0));




    myHand = player1.addCard(myHand, player1, myList, myMap, myBust, myHandValue, define);
    comHand = playercom.computerChoice(comHand, playercom, myList, myMap, comHandValue, myBust, define);




    myHandValue = player1.getValue(myHand, myMap);
    comHandValue = playercom.getValue(comHand, myMap);

    myBust = player1.checkBust(myHand, player1, myList, myMap, myHandValue);
    comBust = playercom.checkBust(myHand, player1, myList, myMap, myHandValue);

    define.Wait();

    if (myHandValue > comHandValue && myBust == true){ // fix comparitives (true false etccc)
      define.printj("Player 1 has won with a hand of: "+ myHand);

    }else if(myHandValue < comHandValue && comBust == true){
      define.printj("Player Com has won with a hand of: "+ comHand);

    }else if((myHandValue == comHandValue) && (myBust == true && comBust == true)){
      define.printj("Player 1 and Player Com have tied, therefore Player Com wins");

    }else if(myBust == false && comBust == false){
      define.printj("Both players have busted");
    }








  }
}
