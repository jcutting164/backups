import java.util.*;

public class UserFunc{

  public UserFunc(){
  }

  public ArrayList<String> getHand(ArrayList<String> theList){
    ArrayList<String> handList = new ArrayList<String>();
    int placeHold = 51;
    Random randomGenerator = new Random();
    for(int counter = 0; counter < 2; counter++){
      int spot = randomGenerator.nextInt(theList.size());
      handList.add(theList.get(spot));
      theList.remove(spot);

    }
    return handList;
  }

  public int getValue(ArrayList<String> handList, HashMap<String, Integer> theMap){
    int handValue = 0;
    int size = handList.size();
    for(int counter = 0; counter < size; counter++){
      String localString = handList.get(counter);
      int localInt = theMap.get(localString);

      handValue = handValue + localInt;
      //handValue = handValue + theMap.get(handList.get(counter));

    }
  return handValue;
  }

  public boolean checkBust(ArrayList<String> handList, UserFunc player, ArrayList<String> theList, HashMap<String, Integer> theMap, int handValue){
    Scanner reader = new Scanner(System.in);
    int check = player.getValue(handList, theMap);
    boolean bust = true;
    if (check > 21){
      bust = false;
    }else if(check < 21){
      bust = true;
    }
    return bust;
  }

  public ArrayList<String> addCard(ArrayList<String> handList, UserFunc player, ArrayList<String> theList, HashMap<String, Integer> theMap, boolean bust, int handValue, Add define){
    Scanner reader = new Scanner(System.in);
    Random randomGenerator = new Random();
    while (bust == true){
      define.printj("Do you want a card? [y/n]: ");
      String userInput;
      userInput = reader.nextLine();
      switch(userInput){
        case "y" :
        int spot = randomGenerator.nextInt(theList.size());
        handList.add(theList.get(spot));
        theList.remove(spot);
        handValue = player.getValue(handList, theMap);
        define.printj("Your hand is: " + handList+ " with a hand value of: " + handValue);
        define.Wait(1200);
        bust = player.checkBust(handList, player, theList, theMap, handValue);
        if (bust == false){
          define.printj("You have busted with a hand of: " + handList + "with a hand value of: " + player.getValue(handList, theMap));
          define.Wait(1200);
        }
        break;

        case "n" :
          bust = false;
          define.printj("You have ended your turn");
          define.Wait(1200);
          define.printj("Your hand is: " + handList+ " with a hand value of: "+ handValue);
          break;

        default:
          define.printj("Input is not equal to yes or no");
          break;
      }
    }
    return handList;
  }

  public ArrayList<String> computerChoice(ArrayList<String> handList, UserFunc player, ArrayList<String> theList, HashMap<String, Integer> theMap, int handValue, boolean bust, Add define, int counter){
    if (bust == false){
      return handList;
    }
    define.printj("Com"+counter+" has a hand of: "+ handList);
    define.Wait(1200);
    while (handValue < 17){
      Scanner reader = new Scanner(System.in);
      Random randomGenerator = new Random();
      int spot = randomGenerator.nextInt(theList.size());
      handList.add(theList.get(spot));
      define.printj("Com"+counter+" drew a: " + theList.get(spot));
      define.Wait(1200);
      theList.remove(spot);
      handValue = player.getValue(handList, theMap);

    }
    return handList;
  }






}
