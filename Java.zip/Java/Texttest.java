import java.util.*;  // imports array list moduol

public class Texttest {

	public Texttest(){
  }

	public void test(String str){
		Add define = new Add();
		String tempStr = str;
		ArrayList<String> myList = new ArrayList<String>(Arrays.asList(tempStr.split("")));
		for(int counter = 0; myList.size()>counter; counter++){
			System.out.print(myList.get(counter));
			define.Wait();
		}
	}


}
