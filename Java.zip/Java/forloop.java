class forloop{
  public static void main(String[] args) {

    for(int counter = 0; counter < 5; counter++){

        System.out.println("The counter value is: " + counter);

    }
  }
}

// the for loop runs a certain block of code until a conditional statement is false
// in this instance, the for loop will run until counter is equal to 5
// each time the loop is run, 1 is added to counter with counter++
