import java.util.*;
public class Test{



  public static void main(String[] args){

    Texttest obj = new Texttest();

    obj.test("This is an extremely cool test isn't it?");
  }
}
