class basicVariables{
  public static void main(String[] args){



    /* this is a multi lined
            comment */

    // this is a single line comment

    int num = 20; // this is a integer variable
    boolean bool = true; //this is a boolean variable
    String sent = "This is a sentance"; //this is a string variable
    char character = 'Y'; // this variable is for single lettered strings. Use of
                          // Single quotes are nessisary for proper syntax


    System.out.println(num);
    System.out.println(bool);
    System.out.println(sent);

    int num2 = 30;
    int num3 = num * num2;

    boolean bool2 = num == num2;
    boolean bool3 = num * num2 == 600;

    System.out.println(bool2);
    System.out.println(bool3);


    // The following code is about "and" "or" and "not"

    System.out.println(!false); /* line 29 represents the "not" function
                                  this line will print true because the not
                                  function will do the opposite of the original
                                  condidtions are.  "Not" is represented by the
                                  "!"
                                */

    System.out.println(1 + 1 == 2 && 2 + 2 == 4); /* The "and" comparative on line
                                                    36 will return True because
                                                    both sides are True.  "and"
                                                    is represented by "&&"
                                                  */

    System.out.println(1 + 1 == 2 || 1 + 0 == 3); /* The "or" comparative on line
                                                    42 will return true if one
                                                    or more sides are true
                                                    "or" is represented with ||
                                                  */
    // side comment: the operators will be read in this order: not, and, or
  }
}
