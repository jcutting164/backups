import java.util.*;
public class BackTest{
  public static void main(String[] args){
    Standard stand = new Standard();
    Integer test = 5;
    System.out.print(test);
    System.out.print("\b");
    stand.Wait(500);
    System.out.print("Health Value: "+ 5+ " ");
    stand.Wait(500);
    System.out.print("\b");
    stand.Wait(500);
    System.out.print(5);
    stand.Wait(500);
    System.out.print("\b\b");
    stand.Wait(500);
    System.out.print(9);
    stand.Wait(500);

  }
}
