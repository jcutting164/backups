import java.util.ArrayList;  // imports array list moduol

public class array_lists {

	public static void main(String[] args) {

		ArrayList<Integer> weeklyTemperatures = new ArrayList<Integer>(); // creates Integer list
		weeklyTemperatures.add(78);       // adds integer to lists
		weeklyTemperatures.add(67);     // adds integer to lists
		weeklyTemperatures.add(89);   // adds integer to lists
		weeklyTemperatures.add(94);     // adds integer to lists
    weeklyTemperatures.add(2, 111);  // inserts integer into specifc position in list (2 is the index #)
                                    // will move all items over 1
                                    // ex: 1, 3, 4
                                    // inserts 2 into index 1
                                    //output: 1,2,3,4
                                    // remember: computers start counting with 0
                                    // 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
    System.out.println(weeklyTemperatures.get(3));  // finds specifc value in specific place with .get


    for (Integer temperature : weeklyTemperatures) {  //more brief for loop that cycles through a list
			System.out.println(temperature);
    }
		System.out.println(weeklyTemperatures);
		weeklyTemperatures.remove(1);
		System.out.println(weeklyTemperatures);

	}
}
