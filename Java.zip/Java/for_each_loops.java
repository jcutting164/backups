import java.util.ArrayList;
class for_each_loops{
  public static void main(String[] args) {
    ArrayList<Integer> weeklyTemperatures = new ArrayList<Integer>(); //makes list and adds items
		weeklyTemperatures.add(78);
		weeklyTemperatures.add(67);
		weeklyTemperatures.add(89);
		weeklyTemperatures.add(94);


    for (Integer temperature : weeklyTemperatures) {  // cycles through weeklyTemperatures
  			 System.out.println(temperature);              // makes int temperature equal to each item
       }                                            // each time the loop, loops
    }
  }
