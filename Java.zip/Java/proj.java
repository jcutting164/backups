public class proj{
  public static void main(String[] args){
    Dog reese = new Dog(1);
    Cat panda = new Cat(6);
    reese.bark();
    panda.scare();
  }
}
