import java.util.HashMap;  // imports hash maps
                        // a hashmap connects a String and an integer
public class hash_maps {
	public static void main(String[] args) {

		HashMap<String, Integer> restaurantMenu = new HashMap<String, Integer>();  // creates hash map

		restaurantMenu.put("Turkey Burger", 13);    //adds new string and integer to hashmap
		restaurantMenu.put("Naan Pizza", 11);       //adds new string and integer to hashmap
		restaurantMenu.put("Cranberry Kale Salad", 10);  //adds new string and integer to hashmap

		System.out.println(restaurantMenu.size());  // prints amount of entries in hashmap

		for (String item : restaurantMenu.keySet()) {  //.keySet method cycles through both string and integer

			System.out.println("A " + item + " costs " + restaurantMenu.get(item) + " dollars.");



		}

		int x = restaurantMenu.get("Turkey Burger");
		System.out.print(x);

	}
}
