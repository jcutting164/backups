class Dog{
  int age;
  public Dog(int dogsAge){
    dogsAge = age;
  }
  public void bark(){              // a void type method will not return any value
    System.out.println("woof");    // int methods can
  }
  public static void main(String[] args){


    Dog spike = new Dog(5); // this is an obj made with the class with given
  }                              //parameters (age)
}
