class if_statements{
  public static void main(String[] args){
    /* the following code
      represents conditional
      statments. A normal 'if'
      statment will test if
      something is true, and
      if it is, it will
      execute a block of code.
      The 'else if' conditional
      is used after an 'if'
      conditional if the original
      'if' statment returns
      false.  'else' will execute
      if the above if and else if
      statments return false */
    int if_test = 12;
    if (if_test > 12) {
      System.out.println("if_test is greater than 12"); // the '{}' contain blocks of code
                                                       // ';' end statments
    }else if (if_test >= 6) {
      System.out.println("if_test is greater or equal to 6");
    }else {
      System.out.println("if_test is less than 6");

    }
    int myNum = 0;
    String myTest = (myNum == 0) ? "True" : "False";  //single lined if statement
                                                      // does not contain else/elseifs
    System.out.println(myTest);

    char input = 'Y';                               // this block of code checks
    switch ( input ) {                           // for specific results, like an if statement
                                              // this is best used if you are expecting
      case 'Y': System.out.println("Yes");   // specific results or answers
                break;

      case 'N': System.out.println("No");
                break;
      default:
        System.out.println("input is not equal to 'Y' or 'N' ");

    }


  }
}
